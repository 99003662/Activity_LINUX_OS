#include "fun.h"
#include <stdio.h>
int main() {
  int a, b, c, d;
  a = 10;
  b = 20;
  c = mul(a, b);
  return c;
}